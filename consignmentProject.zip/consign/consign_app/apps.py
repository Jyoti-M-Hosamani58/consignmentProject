from django.apps import AppConfig


class ConsignAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'consign_app'
